const API_URL = 'https://jsonplaceholder.typicode.com';
const reloadButton = document.querySelector('#reloadButton');
const statusBox = document.querySelector('#status');
const usersBox = document.querySelector('#users');
const postsBox = document.querySelector('#posts');
const searchInput = document.querySelector('#searchInput');
const sortSelect = document.querySelector('#sortSelect');
const userTotal = document.querySelector('#userTotal');
const postTotal = document.querySelector('#postTotal');
const requestTotal = document.querySelector('#requestTotal');
const postCount = document.querySelector('#postCount');

let allUsers = [];
let allPosts = [];
let requestsMade = 0;

function setStatus(message, type = '') {
  statusBox.textContent = message;
  statusBox.className = `status ${type}`.trim();
}

async function fetchJson(url) {
  requestsMade += 1;
  requestTotal.textContent = String(requestsMade);
  const response = await fetch(url);
  // fetch не отклоняет Promise только из-за HTTP-статуса 404/500.
  if (!response.ok) {
    throw new Error(`Ошибка HTTP ${response.status}`);
  }
  return response.json();
}

async function loadData() {
  reloadButton.disabled = true;
  setStatus('Загрузка пользователей и публикаций…');
  usersBox.replaceChildren();
  postsBox.replaceChildren();

  try {
    // Оба независимых ресурса запрашиваются параллельно.
    const [users, posts] = await Promise.all([
      fetchJson(`${API_URL}/users`),
      fetchJson(`${API_URL}/posts`)
    ]);

    if (!Array.isArray(users) || !Array.isArray(posts)) {
      throw new Error('Сервер вернул данные в неожиданном формате.');
    }

    allUsers = users;
    allPosts = posts.slice(0, 10);

    userTotal.textContent = String(allUsers.length);
    postTotal.textContent = String(allPosts.length);
    renderUsers();
    renderPosts();
    setStatus(`Успех: загружено пользователей — ${allUsers.length}, публикаций — ${posts.length}.`, 'success');
  } catch (error) {
    allUsers = [];
    allPosts = [];
    userTotal.textContent = '—';
    postTotal.textContent = '—';
    usersBox.replaceChildren();
    postsBox.replaceChildren();
    setStatus(`Не удалось загрузить данные: ${error.message}. Проверьте интернет и нажмите кнопку повторной загрузки.`, 'error');
    postCount.textContent = 'Данные пока недоступны.';
  } finally {
    reloadButton.disabled = false;
  }
}

function renderUsers() {
  usersBox.replaceChildren();
  const users = [...allUsers];
  const mode = sortSelect.value;

  users.sort((a, b) => {
    const aCount = allPosts.length ? allPosts.filter(post => post.userId === a.id).length : 0;
    const bCount = allPosts.length ? allPosts.filter(post => post.userId === b.id).length : 0;
    if (mode === 'posts-desc') return bCount - aCount || a.id - b.id;
    if (mode === 'posts-asc') return aCount - bCount || a.id - b.id;
    if (mode === 'name') return a.name.localeCompare(b.name);
    return a.id - b.id;
  });

  if (users.length === 0) {
    const empty = document.createElement('p');
    empty.className = 'empty';
    empty.textContent = 'Пользователи не загружены.';
    usersBox.append(empty);
    return;
  }

  for (const user of users) {
    const card = document.createElement('article');
    card.className = 'user-card';

    const name = document.createElement('h3');
    name.textContent = `${user.id}. ${user.name}`;
    const username = document.createElement('p');
    username.textContent = `Логин: ${user.username}`;
    const email = document.createElement('p');
    email.textContent = `Email: ${user.email}`;
    const count = document.createElement('span');
    count.className = 'count';
    const total = allPosts.filter(post => post.userId === user.id).length;
    count.textContent = `Публикаций в показанном списке: ${total}`;

    card.append(name, username, email, count);
    usersBox.append(card);
  }
}

function renderPosts() {
  postsBox.replaceChildren();
  const query = searchInput.value.trim().toLocaleLowerCase('ru');
  const filtered = allPosts.filter(post =>
    post.title.toLocaleLowerCase('ru').includes(query)
  );

  postCount.textContent = `Показано: ${filtered.length} из ${allPosts.length} публикаций.`;
  if (filtered.length === 0) {
    const empty = document.createElement('li');
    empty.className = 'empty';
    empty.textContent = allPosts.length
      ? 'По вашему запросу ничего не найдено.'
      : 'Публикации не загружены.';
    postsBox.append(empty);
    return;
  }

  for (const post of filtered) {
    const item = document.createElement('li');
    const id = document.createElement('span');
    id.className = 'post-id';
    id.textContent = `#${post.id}`;
    const title = document.createElement('span');
    title.className = 'post-title';
    title.textContent = post.title;
    item.append(id, title);
    postsBox.append(item);
  }
}

reloadButton.addEventListener('click', loadData);
searchInput.addEventListener('input', renderPosts);
sortSelect.addEventListener('change', renderUsers);

// Данные загружаются автоматически при открытии страницы.
loadData();
